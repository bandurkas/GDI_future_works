'use client';
import { useLanguage } from './LanguageContext';

export function ClientPrice({ price, originalPrice }: { price: number; originalPrice?: number }) {
    const { formatPrice } = useLanguage();

    if (originalPrice !== undefined) {
        return (
            <>
                <span>{formatPrice(price)}</span>
                <span style={{ textDecoration: 'line-through', color: 'var(--text-muted)', fontSize: '0.8em', marginLeft: '6px' }}>
                    {formatPrice(originalPrice)}
                </span>
            </>
        );
    }
    return <span>{formatPrice(price)}</span>;
}

export function ClientPriceSplit({ price }: { price: number }) {
    const { formatPrice } = useLanguage();
    const formatted = formatPrice(price);
    const parts = formatted.split(' ');
    const currency = parts[0];
    const amount = parts.slice(1).join(' ');

    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', lineHeight: '1.2' }}>
            <span style={{ fontSize: '1.25rem', fontWeight: 800, color: '#111827' }}>{currency}</span>
            <span style={{ fontSize: '2rem', fontWeight: 800, color: '#111827', letterSpacing: '-0.02em' }}>{amount}</span>
        </div>
    );
}

export function Translate({ tKey, defaultText }: { tKey: string, defaultText?: string }) {
    const { t, language } = useLanguage();
    // If we only passed the key, use the context.
    // In our quick dictionary, we return the string, or fallback
    return <span>{t(tKey) !== tKey ? t(tKey) : defaultText || tKey}</span>;
}
