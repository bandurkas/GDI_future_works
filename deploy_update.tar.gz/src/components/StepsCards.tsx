'use client';

import React, { useEffect, useRef, useState } from 'react';
import styles from './StepsCards.module.css';
import Image from 'next/image';

const steps = [
    {
        id: '01',
        title: 'LEARN',
        desc: 'Access live IT courses taught by industry professionals.',
        imgSrc: '/assets/icons/step_learn.png'
    },
    {
        id: '02',
        title: 'BUILD',
        desc: 'Develop hands-on projects and create a strong portfolio.',
        imgSrc: '/assets/icons/step_build.png'
    },
    {
        id: '03',
        title: 'LAUNCH',
        desc: 'Start your career or new venture with expert support.',
        imgSrc: '/assets/icons/step_launch.png'
    }
];

export default function StepsCards() {
    const [isVisible, setIsVisible] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                }
            },
            { threshold: 0.15 }
        );

        if (containerRef.current) {
            observer.observe(containerRef.current);
        }

        return () => {
            if (containerRef.current) observer.unobserve(containerRef.current);
        };
    }, []);

    return (
        <section className={styles.sectionContainer}>
            <div className={styles.container} ref={containerRef}>
                <div className={styles.grid}>
                    {steps.map((step, index) => (
                        <div
                            key={step.id}
                            className={`${styles.card} ${isVisible ? styles.visible : ''}`}
                            style={{ transitionDelay: `${index * 150}ms` }}
                        >
                            <div className={styles.stepNumber}>{step.id}</div>

                            <div className={styles.iconWrapper}>
                                <div className={styles.glowEffect} />
                                <Image
                                    src={step.imgSrc}
                                    width={200}
                                    height={200}
                                    alt={step.title}
                                    className={`${styles.iconImage} ${isVisible ? styles.animateFloat : ''}`}
                                    unoptimized
                                    style={{ animationDelay: `${(index * 150) + 400}ms` }}
                                />
                            </div>

                            <h3 className={styles.title}>{step.title}</h3>
                            <p className={styles.desc}>{step.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
