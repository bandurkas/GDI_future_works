'use client';

import React, { useEffect, useRef, useState } from 'react';
import styles from './InteractiveSlider.module.css';
import Image from 'next/image';

const slides = [
    {
        id: '01',
        word: 'Learn',
        color: '#10B981', // Green for left-side word indicator
        title: 'LEARN',
        desc: 'Access live IT courses taught\nby deep-industry professionals.',
        imgSrc: '/assets/icons/step_learn.png',
        icon: (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                <path d="M6 12v5c3 3 9 3 12 0v-5" />
            </svg>
        )
    },
    {
        id: '02',
        word: 'Build',
        color: '#3B82F6', // Blue for left-side word indicator
        title: 'BUILD',
        desc: 'Develop hands-on projects\nand portfolio pieces.',
        imgSrc: '/assets/icons/step_build.png',
        icon: (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
        )
    },
    {
        id: '03',
        word: 'Launch',
        color: '#EF4444', // Red for left-side word indicator
        title: 'LAUNCH',
        desc: 'Start your career or new venture\nwith expert support.',
        imgSrc: '/assets/icons/step_launch.png',
        icon: (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M13.5 2.5a2.121 2.121 0 0 0-3 0L3 10l3.5 13 4.5-5 4.5 5 3.5-13-7.5-7.5z" />
                <path d="M10.5 13.5 3 10M13.5 13.5 21 10" />
            </svg>
        )
    }
];

export default function InteractiveSlider() {
    const [activeIdx, setActiveIdx] = useState(0);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleScroll = () => {
            if (!containerRef.current) return;
            const rect = containerRef.current.getBoundingClientRect();
            const viewportHeight = window.innerHeight;

            // Calculates scroll progression through the 180vh/300vh container
            let progress = -rect.top / (rect.height - viewportHeight);
            progress = Math.max(0, Math.min(1, progress));

            if (progress < 0.33) setActiveIdx(0);
            else if (progress < 0.66) setActiveIdx(1);
            else setActiveIdx(2);
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll(); // Init
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className={styles.scrollWrapper} ref={containerRef} data-active={activeIdx}>
            <div className={styles.stickyContainer}>

                {/* Main animated interface */}
                <div className={styles.interfaceGrid}>

                    {/* Left: The Jeton "Word Stack" */}
                    <div className={styles.wordsColumn}>
                        <div className={styles.wordsWindow}>
                            <div className={styles.wordsTrack}>
                                {slides.map((s, i) => {
                                    const isActive = i === activeIdx;
                                    return (
                                        <div key={s.id} className={`${styles.wordItem} ${isActive ? styles.activeWord : styles.inactiveWord}`}>
                                            <div
                                                className={styles.wordIconWrap}
                                                style={{
                                                    backgroundColor: isActive ? s.color : '#E5E7EB',
                                                    color: isActive ? '#fff' : '#9CA3AF'
                                                }}
                                            >
                                                {s.icon}
                                            </div>
                                            <span style={{ color: isActive ? s.color : undefined }}>
                                                {s.word}
                                            </span>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>

                    {/* Right: The dynamic visual card display using the newly generated static design UI */}
                    <div className={styles.visualsColumn}>
                        <div className={styles.cardFrame}>
                            <div
                                className={styles.cardContentTrack}
                                style={{ transform: `translateY(-${activeIdx * 100}%)` }}
                            >
                                {slides.map((s) => (
                                    <div key={s.id} className={styles.cardScreen}>
                                        <div className={styles.stepNumber}>{s.id}</div>
                                        <div className={styles.iconWrapper}>
                                            <Image
                                                src={s.imgSrc}
                                                width={180}
                                                height={180}
                                                alt={s.title}
                                                className={styles.iconImage}
                                                unoptimized
                                            />
                                        </div>
                                        <h3 className={styles.title}>{s.title}</h3>
                                        <p className={styles.desc}>
                                            {s.desc.split('\n').map((line, j) => (
                                                <React.Fragment key={j}>
                                                    {line}
                                                    {j < 1 && <br />}
                                                </React.Fragment>
                                            ))}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
}
