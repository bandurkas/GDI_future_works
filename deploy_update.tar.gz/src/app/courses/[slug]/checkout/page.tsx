'use client';
import { useState, use } from 'react';
import Link from 'next/link';
import { getCourseBySlug } from '@/data/courses';
import { Translate, ClientPriceSplit } from '@/components/ClientTranslations';
import styles from './page.module.css';

type Props = { params: Promise<{ slug: string }> };

declare global {
    interface Window {
        snap: any;
    }
}

export default function CheckoutPage({ params }: Props) {
    const { slug } = use(params);
    const course = getCourseBySlug(slug);
    const [form, setForm] = useState({ name: '', whatsapp: '' });
    const [loading, setLoading] = useState(false);

    const onChange = (e: React.ChangeEvent<HTMLInputElement>) =>
        setForm(f => ({ ...f, [e.target.name]: e.target.value }));

    const isValid = form.name.trim().length > 1 && form.whatsapp.trim().length > 6;

    if (!course) return null;

    const handlePay = async () => {
        if (!isValid || loading) return;
        setLoading(true);

        try {
            const res = await fetch('/api/tokenize', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: course.id,
                    name: course.title,
                    price: course.price * 16800,
                })
            });

            const data = await res.json();

            if (data.token && typeof window.snap !== 'undefined') {
                window.snap.pay(data.token, {
                    onSuccess: function (result: any) {
                        window.location.href = `/courses/${slug}/confirmation`;
                    },
                    onPending: function (result: any) {
                        alert('Waiting for your payment!');
                        setLoading(false);
                    },
                    onError: function (result: any) {
                        alert('Payment failed!');
                        setLoading(false);
                    },
                    onClose: function () {
                        setLoading(false);
                    }
                });
            } else {
                alert('Payment gateway could not be loaded. Check your internet connection or keys.');
                setLoading(false);
            }
        } catch (error) {
            console.error(error);
            alert('A network error occurred.');
            setLoading(false);
        }
    };

    return (
        <div className={styles.page}>
            <div className="container">
                <div className={styles.inner}>
                    {/* Progress */}
                    <div className={styles.progress}>
                        {[{ n: 1, l: 'Select Time' }, { n: 2, l: 'Your Details' }, { n: 3, l: 'Payment' }].map((s, i) => (
                            <div key={s.n} className={styles.progressStep}>
                                <div className={`${styles.stepBubble} ${s.n < 2 ? styles.done : ''} ${s.n === 2 ? styles.active : ''}`}>
                                    {s.n < 2 ? '✓' : s.n}
                                </div>
                                <span className={`${styles.stepLabel} ${s.n === 2 ? styles.activeLbl : ''}`}>{s.l}</span>
                                {i < 2 && <div className={`${styles.line} ${s.n < 2 ? styles.lineDone : ''}`} />}
                            </div>
                        ))}
                    </div>

                    <div>
                        <h1 className={styles.title}>Almost there.</h1>
                        <p className={styles.subtitle}>Just 2 short fields to secure your spot.</p>
                    </div>

                    <div className={styles.checkoutContainer}>
                        {/* Single Form & Summary Card */}
                        <div className={styles.checkoutCard}>

                            {/* Order Summary Block at top of form */}
                            {/* Order Summary Block at top of form */}
                            <div className={styles.summarySection}>
                                <div className={styles.summaryCourse}>
                                    <div className={styles.summaryIcon} style={{ background: course.iconBg }}>
                                        {course.icon}
                                    </div>
                                    <div className={styles.summaryTextWrap}>
                                        <div className={styles.summaryName}>
                                            {course.title.split(' ').map((word, i) => (
                                                <div key={i}>{word}</div>
                                            ))}
                                        </div>
                                        <div className={styles.summaryMeta}>
                                            Live Session · 📅<br />{course.nextSession}
                                        </div>
                                    </div>
                                </div>

                                <div className={styles.summaryDashed} />

                                <div className={styles.summaryPriceRow}>
                                    <div className={styles.priceLabelStack}>
                                        <span>Total</span>
                                        <span>Due</span>
                                    </div>
                                    <div className={styles.priceValueStack}>
                                        <ClientPriceSplit price={course.price} />
                                    </div>
                                </div>
                            </div>

                            <div className={styles.divider} />

                            <h3 className={styles.formTitle}>Your Details</h3>

                            <div className="form-group">
                                <label className="form-label" htmlFor="name">Full Name *</label>
                                <input
                                    id="name" name="name" type="text"
                                    className="form-input"
                                    placeholder="e.g. Arif Setiyawan"
                                    value={form.name} onChange={onChange}
                                    autoComplete="name"
                                />
                            </div>

                            <div className="form-group">
                                <label className="form-label" htmlFor="whatsapp">WhatsApp Number *</label>
                                <input
                                    id="whatsapp" name="whatsapp" type="tel"
                                    className="form-input"
                                    placeholder="+62 812 3456 7890"
                                    value={form.whatsapp} onChange={onChange}
                                    autoComplete="tel"
                                />
                            </div>

                            <button
                                onClick={handlePay}
                                className={`btn btn-primary btn-lg btn-full ${!isValid || loading ? styles.disabled : ''}`}
                                disabled={!isValid || loading}
                                id="checkout-to-payment-btn"
                            >
                                {loading ? 'Processing...' : 'Proceed to Payment →'}
                            </button>

                            {!isValid && (
                                <p className={styles.validationHint}>Fill your name and WhatsApp to continue</p>
                            )}

                            <Link href={`/courses/${slug}/schedule`} className={styles.back}>← Back to schedule</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
